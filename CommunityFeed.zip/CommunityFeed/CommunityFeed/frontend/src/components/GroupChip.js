import React from 'react';
import { Pressable, Text, StyleSheet } from 'react-native';
import { groupColors, radius, spacing, typography } from '../theme/theme';

export default function GroupChip({ label, groupId, onPress, active = false }) {
  const palette = groupColors(groupId);
  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.chip,
        { backgroundColor: active ? palette.fg : palette.bg },
      ]}
    >
      <Text style={[styles.text, { color: active ? '#fff' : palette.fg }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: 7,
    borderRadius: radius.pill,
    marginRight: spacing.sm,
  },
  text: { ...typography.caption, fontWeight: '700' },
});
