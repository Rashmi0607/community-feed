import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, spacing, typography } from '../theme/theme';

export default function EmptyState({ title, subtitle }) {
  return (
    <View style={styles.container}>
      <Text style={styles.emoji}>🗒️</Text>
      <Text style={styles.title}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: 'center', marginTop: 80, paddingHorizontal: spacing.xl },
  emoji: { fontSize: 36, marginBottom: spacing.sm },
  title: { ...typography.bodyBold, color: colors.textMuted, textAlign: 'center' },
  subtitle: { ...typography.caption, marginTop: 4, textAlign: 'center' },
});
