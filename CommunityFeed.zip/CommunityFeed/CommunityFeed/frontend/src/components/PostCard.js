import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import Avatar from './Avatar';
import { colors, groupColors, radius, spacing, shadow, typography } from '../theme/theme';
import formatRelativeTime from '../utils/formatRelativeTime';
import { toggleLikeRequest } from '../api/posts';

export default function PostCard({ post, onPressGroup, hideGroupTag = false }) {
  const [likeCount, setLikeCount] = useState(post.likeCount);
  const [likedByMe, setLikedByMe] = useState(post.likedByMe);
  const [busy, setBusy] = useState(false);
  const palette = groupColors(post.groupId);

  const handleLike = async () => {
    if (busy) return;
    setBusy(true);
    const nextLiked = !likedByMe;
    setLikedByMe(nextLiked);
    setLikeCount((c) => c + (nextLiked ? 1 : -1));
    try {
      const updated = await toggleLikeRequest(post.id);
      setLikedByMe(updated.likedByMe);
      setLikeCount(updated.likeCount);
    } catch (err) {
      setLikedByMe(likedByMe);
      setLikeCount(post.likeCount);
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <Avatar name={post.userName} isAnonymous={post.isAnonymous} />
        <View style={styles.headerText}>
          <Text style={styles.userName}>{post.userName}</Text>
          <Text style={styles.time}>{formatRelativeTime(post.createdAt)}</Text>
        </View>

        {!hideGroupTag && (
          <Pressable
            onPress={() => onPressGroup?.(post.groupId, post.groupName)}
            style={[styles.groupTag, { backgroundColor: palette.bg }]}
          >
            <Text style={[styles.groupTagText, { color: palette.fg }]}>{post.groupName}</Text>
          </Pressable>
        )}
      </View>

      <Text style={styles.content}>{post.content}</Text>

      <View style={styles.footerRow}>
        <Pressable style={styles.likeButton} onPress={handleLike} hitSlop={8}>
          <Text style={likedByMe ? styles.likedText : styles.likeText}>
            {likedByMe ? '♥' : '♡'} {likeCount}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginHorizontal: spacing.md,
    marginVertical: 6,
    ...shadow.card,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm },
  headerText: { marginLeft: spacing.sm, flex: 1 },
  userName: { ...typography.bodyBold },
  time: { ...typography.small, marginTop: 1 },
  groupTag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill },
  groupTagText: { fontSize: 12, fontWeight: '700' },
  content: { ...typography.body, lineHeight: 21, marginBottom: spacing.sm },
  footerRow: { flexDirection: 'row', alignItems: 'center' },
  likeButton: { paddingVertical: 2, paddingRight: 8 },
  likeText: { fontSize: 14, color: colors.textMuted, fontWeight: '600' },
  likedText: { fontSize: 14, color: colors.danger, fontWeight: '700' },
});
