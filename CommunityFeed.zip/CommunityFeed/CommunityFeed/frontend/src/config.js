import { Platform } from 'react-native';


const LOCAL_HOST = Platform.select({
  android: '10.0.2.2',
  default: 'localhost',
});



export const API_BASE_URL = `http://${LOCAL_HOST}:8081/api`;

export const GROUPS = [
  { id: 'fitness', name: 'Fitness' },
  { id: 'travel', name: 'Travel' },
  { id: 'food', name: 'Food' },
  { id: 'tech', name: 'Technology'},
  { id: 'life', name: "Lifestyle"}
];
