
export const colors = {
  background: '#F5F6FA',
  surface: '#FFFFFF',
  primary: '#4F6DF5',
  primaryDark: '#3B54D6',
  primarySoft: '#EEF1FF',
  text: '#1A1A1E',
  textMuted: '#6B7080',
  textFaint: '#9AA0AC',
  border: '#E7E8EF',
  danger: '#E0245E',
  success: '#1FA971',
  white: '#FFFFFF',
};

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 };

export const radius = { sm: 8, md: 12, lg: 18, pill: 999 };

export const typography = {
  h1: { fontSize: 28, fontWeight: '800', color: colors.text },
  h2: { fontSize: 20, fontWeight: '700', color: colors.text },
  body: { fontSize: 15, fontWeight: '400', color: colors.text },
  bodyBold: { fontSize: 15, fontWeight: '700', color: colors.text },
  caption: { fontSize: 12.5, fontWeight: '500', color: colors.textMuted },
  small: { fontSize: 12, color: colors.textFaint },
};

export const shadow = {
  card: {
    shadowColor: '#12142B',
    shadowOpacity: 0.06,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
};

const GROUP_PALETTE = {
  fitness: { bg: '#FFEFE6', fg: '#D2691E' },
  travel: { bg: '#E8F3FF', fg: '#1F6FEB' },
  food: { bg: '#EAF9EE', fg: '#1FA971' },
  life: { bg: '#B4E1EB', fg: '#FBEFEF'},
  tech: { bg: '#408175', fg: '#FFFAF3'},
};

export const groupColors = (groupId) =>
  GROUP_PALETTE[groupId] || { bg: colors.primarySoft, fg: colors.primary };
