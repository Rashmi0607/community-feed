import client from './client';

export const registerRequest = (name, email, password) =>
  client.post('/auth/register', { name, email, password }).then((r) => r.data);

export const loginRequest = (email, password) =>
  client.post('/auth/login', { email, password }).then((r) => r.data);

export const guestLoginRequest = () =>
  client.post('/auth/guest').then((r) => r.data);

export const meRequest = () => client.get('/auth/me').then((r) => r.data);
