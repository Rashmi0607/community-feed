import client from './client';

export const fetchHomeFeed = () => client.get('/posts').then((r) => r.data);

export const fetchGroupFeed = (groupId) =>
  client.get(`/posts/group/${groupId}`).then((r) => r.data);

export const createPostRequest = ({ content, groupId, groupName, isAnonymous }) =>
  client.post('/posts', { content, groupId, groupName, isAnonymous }).then((r) => r.data);

export const toggleLikeRequest = (postId) =>
  client.patch(`/posts/${postId}/like`).then((r) => r.data);
