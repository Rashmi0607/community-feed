import client from './client';

export const fetchGroups = () => client.get('/groups').then((r) => r.data);
