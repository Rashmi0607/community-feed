import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { registerRequest, loginRequest, guestLoginRequest, meRequest } from '../api/auth';

const AuthContext = createContext(null);
const TOKEN_KEY = 'auth_token';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const token = await AsyncStorage.getItem(TOKEN_KEY);
        if (token) {
          const { user: me } = await meRequest();
          setUser(me);
        }
      } catch (err) {
        await AsyncStorage.removeItem(TOKEN_KEY);
      } finally {
        setInitializing(false);
      }
    })();
  }, []);

  const persistSession = async (token, userData) => {
    await AsyncStorage.setItem(TOKEN_KEY, token);
    setUser(userData);
  };

  const login = useCallback(async (email, password) => {
    const { token, user: userData } = await loginRequest(email, password);
    await persistSession(token, userData);
  }, []);

  const signup = useCallback(async (name, email, password) => {
    const { token, user: userData } = await registerRequest(name, email, password);
    await persistSession(token, userData);
  }, []);

  const loginAsGuest = useCallback(async () => {
    const { token, user: userData } = await guestLoginRequest();
    await persistSession(token, userData);
  }, []);

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem(TOKEN_KEY);
    setUser(null);
  }, []);

  const value = { user, initializing, login, signup, loginAsGuest, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
