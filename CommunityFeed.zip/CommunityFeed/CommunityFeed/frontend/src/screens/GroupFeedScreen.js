import React, { useCallback, useEffect, useState } from 'react';
import { View, FlatList, StyleSheet, RefreshControl, ActivityIndicator } from 'react-native';
import { fetchGroupFeed } from '../api/posts';
import PostCard from '../components/PostCard';
import EmptyState from '../components/EmptyState';
import { colors, spacing } from '../theme/theme';

export default function GroupFeedScreen({ route, navigation }) {
  const { groupId, groupName } = route.params;
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await fetchGroupFeed(groupId);
      setPosts(data);
    } catch (err) {
      // pull-to-refresh is the retry path
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [groupId]);

  useEffect(() => {
    navigation.setOptions({ title: `${groupName} Feed` });
    const unsubscribe = navigation.addListener('focus', load);
    return unsubscribe;
  }, [navigation, groupName, load]);

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  return (
    <View style={styles.container}>
      {loading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={colors.primary} />
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <PostCard post={item} hideGroupTag />}
          contentContainerStyle={{ paddingVertical: spacing.sm, paddingBottom: spacing.xxl }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
          ListEmptyComponent={<EmptyState title={`No posts in ${groupName} yet`} subtitle="Check back soon." />}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
});
