import React, { useCallback, useEffect, useState } from 'react';
import { View, FlatList, StyleSheet, RefreshControl, ActivityIndicator } from 'react-native';
import { fetchHomeFeed } from '../api/posts';
import PostCard from '../components/PostCard';
import GroupChip from '../components/GroupChip';
import EmptyState from '../components/EmptyState';
import { GROUPS } from '../config';
import { colors, spacing } from '../theme/theme';

export default function HomeScreen({ navigation }) {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await fetchHomeFeed();
      setPosts(data);
    } catch (err) {
      // Swallow silently here; a pull-to-refresh retry is the recovery path.
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', load);
    return unsubscribe;
  }, [navigation, load]);

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const goToGroup = (groupId, groupName) => {
    navigation.navigate('GroupFeed', { groupId, groupName });
  };

  return (
    <View style={styles.container}>
      <View style={styles.chipRow}>
        {GROUPS.map((g) => (
          <GroupChip key={g.id} groupId={g.id} label={g.name} onPress={() => goToGroup(g.id, g.name)} />
        ))}
      </View>

      {loading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={colors.primary} />
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <PostCard post={item} onPressGroup={goToGroup} />}
          contentContainerStyle={{ paddingVertical: spacing.sm, paddingBottom: spacing.xxl }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
          ListEmptyComponent={
            <EmptyState title="No posts yet" subtitle="Be the first to share something with the community." />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  chipRow: { flexDirection: 'row', paddingHorizontal: spacing.md, paddingTop: spacing.md, paddingBottom: spacing.xs },
});
