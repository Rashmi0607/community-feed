import React, { useState } from 'react';
import { View, Text, StyleSheet, Switch, Alert, ScrollView } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { createPostRequest } from '../api/posts';
import Input from '../components/Input';
import Button from '../components/Button';
import GroupChip from '../components/GroupChip';
import { GROUPS } from '../config';
import { colors, spacing, typography } from '../theme/theme';

export default function CreatePostScreen({ navigation }) {
  const { user } = useAuth();
  const [content, setContent] = useState('');
  const [groupId, setGroupId] = useState(GROUPS[0].id);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handlePost = async () => {
    if (!content.trim()) {
      Alert.alert('Empty post', 'Write something before posting.');
      return;
    }
    const group = GROUPS.find((g) => g.id === groupId);
    setSubmitting(true);
    try {
      await createPostRequest({
        content: content.trim(),
        groupId: group.id,
        groupName: group.name,
        isAnonymous,
      });
      setContent('');
      setIsAnonymous(false);
      navigation.navigate('Home');
    } catch (err) {
      Alert.alert('Couldn\u2019t post', err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: spacing.lg }}>
      <Text style={styles.label}>Posting as</Text>
      <Text style={styles.asName}>{isAnonymous ? 'Anonymous User' : user?.name}</Text>

      <Input
        multiline
        placeholder="Share something with the community..."
        value={content}
        onChangeText={setContent}
        style={{ marginTop: spacing.md }}
      />

      <Text style={styles.label}>Group</Text>
      <View style={styles.groupRow}>
        {GROUPS.map((g) => (
          <GroupChip
            key={g.id}
            groupId={g.id}
            label={g.name}
            active={groupId === g.id}
            onPress={() => setGroupId(g.id)}
          />
        ))}
      </View>

      <View style={styles.toggleRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.label}>Post Anonymously</Text>
          <Text style={styles.hint}>
            Shows as "Anonymous User", but your account stays linked to the post for moderation.
          </Text>
        </View>
        <Switch value={isAnonymous} onValueChange={setIsAnonymous} />
      </View>

      <Button title="Post" onPress={handlePost} loading={submitting} style={{ marginTop: spacing.lg }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  label: { ...typography.caption, marginBottom: 6, marginTop: spacing.md },
  asName: { ...typography.bodyBold },
  groupRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: spacing.xs },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.xl,
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: spacing.md,
  },
  hint: { ...typography.small, marginTop: 4, paddingRight: spacing.md },
});
