import React, { useState } from 'react';
import {View,Text,StyleSheet,Alert,KeyboardAvoidingView,Platform,ScrollView} from 'react-native';
import { useAuth } from '../context/AuthContext';
import Input from '../components/Input';
import Button from '../components/Button';
import { colors, spacing, typography } from '../theme/theme';

export default function LoginScreen({ navigation }) {
  const { login, loginAsGuest } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [guestLoading, setGuestLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Missing info', 'Please enter your email and password.');
      return;
    }
    setLoading(true);
    try {
      await login(email.trim(), password);
    } catch (err) {
      Alert.alert('Couldn\u2019t log in', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGuest = async () => {
    setGuestLoading(true);
    try {
      await loginAsGuest();
    } catch (err) {
      Alert.alert('Couldn\u2019t continue as guest', err.message);
    } finally {
      setGuestLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>Community Feed</Text>
        <Text style={styles.subtitle}>Welcome back \u2014 log in to continue</Text>

        <Input
          label="Email"
          placeholder="you@example.com"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
        />
        <Input
          label="Password"
          placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <Button title="Log In" onPress={handleLogin} loading={loading} style={{ marginTop: 4 }} />

        <Button
          title="Need an account? Sign up"
          variant="ghost"
          onPress={() => navigation.navigate('Signup')}
        />

        <View style={styles.divider} />

        <Button
          title="Continue as Guest"
          variant="outline"
          onPress={handleGuest}
          loading={guestLoading}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.background },
  container: { flexGrow: 1, justifyContent: 'center', padding: spacing.xl },
  title: { ...typography.h1, textAlign: 'center', marginBottom: 4 },
  subtitle: { ...typography.caption, textAlign: 'center', marginBottom: spacing.xxl, fontSize: 14 },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: spacing.lg },
});
