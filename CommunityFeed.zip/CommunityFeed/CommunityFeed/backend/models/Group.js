const mongoose = require('mongoose');

const groupSchema = new mongoose.Schema({
  _id: { type: String }, // slug, e.g. "fitness"
  name: { type: String, required: true },
});

module.exports = mongoose.model('Group', groupSchema);
