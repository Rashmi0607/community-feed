const mongoose = require('mongoose');

// A single "posts" collection is the source of truth for both the Home
// Feed and every Group Feed. Home Feed reads it unfiltered; Group Feed
// reads the same collection filtered by groupId — no document is ever
// duplicated across collections.
const postSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true, // always the real author, even when isAnonymous is true
    },
    userName: { type: String, required: true }, // "Anonymous User" snapshot when isAnonymous
    groupId: { type: String, required: true, index: true },
    groupName: { type: String, required: true },
    content: { type: String, required: true, trim: true, maxlength: 2000 },
    isAnonymous: { type: Boolean, default: false },
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  },
  { timestamps: { createdAt: 'createdAt', updatedAt: false } }
);

postSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Post', postSchema);
