const Group = require('../models/Group');

const DEFAULT_GROUPS = [
  { _id: 'fitness', name: 'Fitness' },
  { _id: 'travel', name: 'Travel' },
  { _id: 'food', name: 'Food' },
];

const seedGroups = async () => {
  const count = await Group.countDocuments();
  if (count === 0) {
    await Group.insertMany(DEFAULT_GROUPS);
    console.log('Seeded default groups: Fitness, Travel, Food');
  }
};

module.exports = seedGroups;
