const Group = require('../models/Group');

exports.getGroups = async (req, res) => {
  try {
    const groups = await Group.find();
    res.json(groups.map((g) => ({ id: g._id, name: g.name })));
  } catch (err) {
    res.status(500).json({ message: 'Failed to load groups', error: err.message });
  }
};
