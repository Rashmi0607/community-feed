const Post = require('../models/Post');

const serializePost = (post, currentUserId) => ({
  id: post._id.toString(),
  userId: post.userId.toString(),
  userName: post.userName,
  groupId: post.groupId,
  groupName: post.groupName,
  content: post.content,
  isAnonymous: post.isAnonymous,
  likeCount: post.likes.length,
  likedByMe: currentUserId ? post.likes.some((id) => id.toString() === currentUserId) : false,
  createdAt: post.createdAt,
});

// Home Feed: every post, newest first. Reads the same "posts" collection
// that Group Feed reads — nothing is duplicated.
exports.getPosts = async (req, res) => {
  try {
    const posts = await Post.find().sort({ createdAt: -1 });
    res.json(posts.map((p) => serializePost(p, req.user.id)));
  } catch (err) {
    res.status(500).json({ message: 'Failed to load feed', error: err.message });
  }
};

// Group Feed: posts filtered to one groupId, newest first.
exports.getPostsByGroup = async (req, res) => {
  try {
    const posts = await Post.find({ groupId: req.params.groupId }).sort({ createdAt: -1 });
    res.json(posts.map((p) => serializePost(p, req.user.id)));
  } catch (err) {
    res.status(500).json({ message: 'Failed to load group feed', error: err.message });
  }
};

exports.createPost = async (req, res) => {
  try {
    const { content, groupId, groupName, isAnonymous } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ message: 'Post content is required' });
    }
    if (!groupId || !groupName) {
      return res.status(400).json({ message: 'groupId and groupName are required' });
    }

    const post = await Post.create({
      userId: req.user.id, // always the real, authenticated user
      userName: isAnonymous ? 'Anonymous User' : req.user.name,
      groupId,
      groupName,
      content: content.trim(),
      isAnonymous: Boolean(isAnonymous),
      likes: [],
    });

    res.status(201).json(serializePost(post, req.user.id));
  } catch (err) {
    res.status(500).json({ message: 'Failed to create post', error: err.message });
  }
};

// Bonus: like / unlike toggle.
exports.toggleLike = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });

    const uid = req.user.id;
    const alreadyLiked = post.likes.some((id) => id.toString() === uid);

    if (alreadyLiked) {
      post.likes = post.likes.filter((id) => id.toString() !== uid);
    } else {
      post.likes.push(uid);
    }

    await post.save();
    res.json(serializePost(post, uid));
  } catch (err) {
    res.status(500).json({ message: 'Failed to update like', error: err.message });
  }
};
