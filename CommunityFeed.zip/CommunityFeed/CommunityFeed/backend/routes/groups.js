const express = require('express');
const router = express.Router();
const requireAuth = require('../middleware/auth');
const { getGroups } = require('../controllers/groupController');

router.get('/', requireAuth, getGroups);

module.exports = router;
