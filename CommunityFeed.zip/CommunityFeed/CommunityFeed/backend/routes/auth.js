const express = require('express');
const router = express.Router();
const requireAuth = require('../middleware/auth');
const { register, login, guestLogin, me } = require('../controllers/authController');

router.post('/register', register);
router.post('/login', login);
router.post('/guest', guestLogin);
router.get('/me', requireAuth, me);

module.exports = router;
