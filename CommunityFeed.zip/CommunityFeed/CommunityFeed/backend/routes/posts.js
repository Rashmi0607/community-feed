const express = require('express');
const router = express.Router();
const requireAuth = require('../middleware/auth');
const { getPosts, getPostsByGroup, createPost, toggleLike } = require('../controllers/postController');

router.use(requireAuth);

router.get('/', getPosts);
router.get('/group/:groupId', getPostsByGroup);
router.post('/', createPost);
router.patch('/:id/like', toggleLike);

module.exports = router;
